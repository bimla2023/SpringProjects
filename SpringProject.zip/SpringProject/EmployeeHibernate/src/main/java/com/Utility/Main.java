package com.Utility;

import org.hibernate.Session;

import com.pojo.Employeehibernate;
import com.Utility.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.buildSessionFactory().openSession();
		session.beginTransaction();
		Employeehibernate employee1 = new Employeehibernate(1,"emp1",23,2345);
		Employeehibernate employee2 = new Employeehibernate(2,"emp2",54,10000);
		session.persist(employee1);
		session.persist(employee2);
		session.getTransaction().commit();
		session.close();
	
	}

}
