package entity;

import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;

public class UserDetailsTest {

	public static void main(String[] args) {
		UserDetails user = new UserDetails();
		user.setName("Ram");
		
		Vehicle vehicle1 = new Vehicle();
		Vehicle vehicle2 = new Vehicle();
		vehicle1.setModelName("CAr");
		vehicle2.setModelName("Jeep");
		
		user.getVehicle().add(vehicle1);
		user.getVehicle().add(vehicle2);
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		try{
			
			Transaction txn = session.getTransaction();
			txn.begin();
			session.save(user);
			session.save(vehicle1);
			session.save(vehicle2);
			session.getTransaction().commit();
			
			
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			session.close();
		}

	}

}
