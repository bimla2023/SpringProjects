package entity;

import jakarta.persistence.Embeddable;

@Embeddable
public class Address {

	private String address;
	private int street_no;
	
	public Address() {
		
	}
	public Address(String address, int street_no) {
	
		this.address = address;
		this.street_no = street_no;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getStreet_no() {
		return street_no;
	}
	public void setStreet_no(int street_no) {
		this.street_no = street_no;
	}

	
	
}
