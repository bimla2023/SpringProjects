package entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity 
@Table(name="Student")
public class Student {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="STUDENTID")
	private Long studentid;
	
	@Column(name="ENTOLLMENTID",nullable=false)
	private String enrollmentId;
	
	@Column(name="NAME")
	private String name;
	
	//for cascading (
	@ManyToOne (cascade = {CascadeType.PERSIST,CascadeType.REMOVE})
    @JoinColumn(name="COURSE_ID")
	private Course course;
	
	public Student() {
		
	}

	public Student(String enrollmentId, String name, Course course) {
	
		this.enrollmentId = enrollmentId;
		this.name = name;
		this.course = course;
	}
	
	
	
}
