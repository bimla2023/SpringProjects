package entity;

import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;

public class PassportMainTest {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.getTransaction();
		try {
			transaction.begin();
			Passport passport = new Passport("12345667");
			Customer customer = new Customer("Name1",passport);
			session.persist(customer);
			transaction.commit();

	}catch(Exception e) {
		e.printStackTrace();
	}finally {
		session.close();
	}

}
}
