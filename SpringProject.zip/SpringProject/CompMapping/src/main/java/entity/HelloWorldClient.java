package entity;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;




public class HelloWorldClient {
	
	
	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.getTransaction();
		try {
			transaction.begin();
			Address address= new Address("Address2",54);
			Employee employee = new Employee("Mane2",546,address);
			session.save(employee);
			transaction.commit();
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			session.close();
		}
		
		
	}
}