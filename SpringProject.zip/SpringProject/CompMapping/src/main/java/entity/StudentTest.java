package entity;

import org.hibernate.Session;
import org.hibernate.Transaction;

import jakarta.persistence.Query;
import util.HibernateUtil;

public class StudentTest {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Session session1 = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.getTransaction();
		Transaction transaction1 = session1.getTransaction();
		
		try {
			transaction.begin();
			
			
			//delete
			Student student1 = session1.get(Student.class, 1);
			if(student1!=null) {
				session.beginTransaction();
				session1.delete(student1);
				session1.getTransaction().commit();
			}
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}

	}

}
