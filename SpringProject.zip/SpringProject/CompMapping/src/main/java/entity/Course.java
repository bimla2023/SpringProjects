package entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="Course")
public class Course {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long course_id;
	
	@Column(name="COURSENAME")
	private String course_name;
	
	@Column(name="COURSEFEE")
	private int course_fee;
	
	public Course() {
		
	}
	public Course(String course_name, int course_fee) {
		
		
		this.course_name = course_name;
		this.course_fee = course_fee;
	}
	
	

}
