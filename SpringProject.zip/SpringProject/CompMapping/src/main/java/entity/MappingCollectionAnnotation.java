package entity;

import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;

public class MappingCollectionAnnotation {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.getTransaction();
		
		session.beginTransaction();
		Friend friend = new Friend("Name1","name1@company.com");
		friend.getNicknames().add("NickNames1");
		friend.getNicknames().add("NickNames2");
		friend.getNicknames().add("NickNames2");
		
		session.persist(friend);
		session.getTransaction().commit();
		session.close();

	}

}
