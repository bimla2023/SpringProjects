package entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity 

public class Passport {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID")
	private Long id;
	
	@Column(name="PassportNumber")
	private String passportNumber;
	
	@OneToOne(mappedBy="passport")
	private Customer customer;
	public Passport() {
		
	}

	public Passport( String passportNumber) {
		
		this.passportNumber = passportNumber;
	}
	public Customer getCustomer() {
		return customer;
	}
	
}
