package org.com.gl.controller;

import java.util.Map;

import org.com.gl.model.Login;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class LoginController {
	
	@RequestMapping(value="/Login",method=RequestMethod.GET)
	public String createLogin() {
	
		
		return "Login";
		
	}
	
	@RequestMapping(value="/Login",method=RequestMethod.POST)
	public String displayLogin(Map<String,Object> model,@RequestParam String User_Id,@RequestParam String password) {
	
		model.put("message","Welcome");
		model.put("User_Id", User_Id);
		model.put("password", password);
		
		return "Display";
		
	}

}
