package org.com.gl.LoginWebMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("org.com.gl")
public class LoginWebMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginWebMvcApplication.class, args);
	}

}
