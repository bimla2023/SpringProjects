package org.com.gl.model;

public class Login {
	private String User_Id;
	private String password;
	
	public Login() {
		
	}
	public Login(String user_Id, String password) {
		super();
		User_Id = user_Id;
		this.password = password;
	}
	public String getUser_Id() {
		return User_Id;
	}
	public void setUser_Id(String user_Id) {
		User_Id = user_Id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
