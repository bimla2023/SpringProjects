package org.com.gl.LoginWebMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginWebMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
