package com.springCore.collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext("/spring/emp.xml");
		{
			Emp emp1 = (Emp) cxt.getBean("emp");
			System.out.println(emp1.getEmpname());
			System.out.println(emp1.getPhones());
			System.out.println(emp1.getAddresses());
			System.out.println(emp1.getCourses());

		}

	}

}
