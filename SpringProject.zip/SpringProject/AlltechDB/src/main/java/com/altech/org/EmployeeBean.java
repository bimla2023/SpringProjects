package com.altech.org;

public class EmployeeBean {
	int empid;
	String empname;
	Address address;

	public EmployeeBean(int empid, String empname, Address address) {
		this.empid = empid;
		this.empname = empname;
		this.address = address;
		toString();

	}

	@Override
	public String toString() {

		return "Employee id : " + this.empid + ", EmpName : " + this.empname;
	}
}
