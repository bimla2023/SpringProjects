package com.altech.org;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainEmployee {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("/spring/beansEmployee.xml");
		Employee emp = context.getBean("emp", Employee.class);
		emp.setId(1);
		emp.setName("Empl1");
		emp.setSalary(23434);
		emp.display();

	}

}
