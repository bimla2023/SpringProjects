package com.altech.lifcycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PersonMain {

	public static void main(String[] args) {
		AbstractApplicationContext cxt = new ClassPathXmlApplicationContext("/spring/person.xml");
		Person person = cxt.getBean("person", Person.class);
		Car car = person.getCar();
		System.out.println("Car model name :" +car.getModel());
		System.out.println("Car Price :" +car.getPrice());
		
	}

}
