package com.altech.lifcycle;

import org.springframework.beans.factory.annotation.Autowired;

public class Person {

	//property annotation
	//@Autowired
	Car car;
	
	//setter
	//@Autowired
	//public Car setcar(Car car) {
	//	return this.car = car;
	//}
	
	//constructor
	//@Autowired
	//public Person(Car car) {
	//	this.car = car;
	//}
	
	
	@Autowired
	//custom method
	public void setcarCustom(Car car) {
		this.car = car;
	 System.out.println("method autowiring");
	}

	public Car getCar() {
		return this.car = car;
	}
	

	

}
