package com.altech.org;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainCollection {

	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext("/spring/beans.xml");
		CollecyionBean bean = cxt.getBean("collectionExample", CollecyionBean.class);
		ArrayList products = (ArrayList) bean.getProducts();
		Map prices = bean.getPrices();
		Set productSet = bean.getProductSet();
		for (int i = 0; i < products.size(); i++) {
			String productName = (String) products.get(i);
			System.out.println("Prices Of : " + productName + " is " + prices.get(productName));
		}

	}

}
