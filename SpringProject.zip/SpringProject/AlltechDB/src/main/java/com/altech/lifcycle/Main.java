package com.altech.lifcycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		AbstractApplicationContext cxt = new ClassPathXmlApplicationContext("/spring/patient.xml");
		Patient patient = cxt.getBean("p", Patient.class);
		System.out.println(patient);
		cxt.registerShutdownHook();
	}

}
