package com.altech.org;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollecyionBean {
	List products;
	Set productSet;
	Map prices;

	public List getProducts() {
		return products;
	}

	public void setProducts(List products) {
		this.products = products;
	}

	public Set getProductSet() {
		return productSet;
	}

	public void setProductSet(Set productSet) {
		this.productSet = productSet;
	}

	public Map getPrices() {
		return prices;
	}

	public void setPrices(Map prices) {
		this.prices = prices;
	}

}
