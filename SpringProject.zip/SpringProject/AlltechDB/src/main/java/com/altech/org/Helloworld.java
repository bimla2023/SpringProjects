package com.altech.org;

public class Helloworld {
	public void message() {
		System.out.println("Hello World");
	}

}
