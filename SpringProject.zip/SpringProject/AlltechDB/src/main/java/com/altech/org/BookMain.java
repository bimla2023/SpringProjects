package com.altech.org;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BookMain {

	public static void main(String[] args) {
		ApplicationContext cxt = new ClassPathXmlApplicationContext("/spring/beans.xml");
		BookConstructor book = cxt.getBean("book", BookConstructor.class);
		System.out.println("Book ID : " + book.getBookid());
		System.out.println("Book Name : " + book.getBookname());
		System.out.println("Book Price : " + book.getBookprice());

	}

}
