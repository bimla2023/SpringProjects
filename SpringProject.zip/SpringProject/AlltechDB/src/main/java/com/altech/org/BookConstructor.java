package com.altech.org;

public class BookConstructor {

	int bookid;
	String bookname;
	float bookprice;

	public BookConstructor(int bookid, String bookname, float bookprice) {
		super();
		this.bookid = bookid;
		this.bookname = bookname;
		this.bookprice = bookprice;
	}

	public int getBookid() {
		return bookid;
	}

	public String getBookname() {
		return bookname;
	}

	public float getBookprice() {
		return bookprice;
	}

}
