package com.altech.org;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// Application context is the container
		ApplicationContext cxt = new ClassPathXmlApplicationContext("/spring/beans.xml");
		EmployeeBean employee = cxt.getBean("employee", EmployeeBean.class);
		System.out.println(employee.toString() + employee.address.toString());

	}

}
