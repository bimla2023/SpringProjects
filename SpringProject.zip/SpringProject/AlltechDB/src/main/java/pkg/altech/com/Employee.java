package pkg.altech.com;

public class Employee {
	int id;
	String name;
	int salary;

	public void display() {
		System.out.println("ID : " + this.id);
		System.out.println("Name : " + this.name);
		System.out.println("Name : " + this.salary);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

}
