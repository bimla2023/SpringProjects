package pkg.altech.com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		// this is the container
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationBeans.class);
		Person person = context.getBean("person", Person.class);
		System.out.println("==Person===");
		System.out.println("Age:" + person.getAge());
		System.out.println("Name:" + person.getName());

		System.out.println("==Employee===");
		Employee employee = context.getBean("employee", Employee.class);
		System.out.println("ID:" + employee.getId());
		System.out.println("Name:" + employee.getName());
		System.out.println("Salary:" + employee.getSalary());

	}

}
