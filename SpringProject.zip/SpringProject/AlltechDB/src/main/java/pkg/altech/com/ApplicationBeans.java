package pkg.altech.com;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//to say this is the container

@Configuration
public class ApplicationBeans {
	// we need to define one person which will return person bean class
	@Bean(name = "person")
	public Person getperson() {
		Person p = new Person();
		p.setAge(24);
		p.setName("Grace");
		return p;

	}

	@Bean(name = "employee")
	public Employee getemployee() {
		Employee emp = new Employee();
		emp.setId(256);
		emp.setName("Emp2");
		emp.setSalary(2233);
		return emp;

	}

}
