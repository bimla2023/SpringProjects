package daoIMPL;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.BookDAO;
import entity.Book;
import jakarta.persistence.Query;
import util.HibernateUtil;

public class BookDAOImpl implements BookDAO{

	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction transaction = session.getTransaction();
	Scanner sc = new Scanner(System.in);



	@Override
	public void create(String book_name,long book_cost) {

		
		//to Insert
		  try {
			  	transaction = session.beginTransaction();
				Book book = new Book(book_name,book_cost);
			    session.persist(book);
			    transaction.commit();
		  }catch(Exception e) {
			  if(transaction!=null) {
				  transaction.rollback();
			  }else {
				  e.printStackTrace();
			  }
		  }
		
			
			session.close();

		
	}
	@Override
	public List<Book> read() {
		Transaction transaction = null;
		String query_read  = "from Book";
		List<Book> bookread = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			bookread = session.createQuery(query_read).list();
			for (Book b : bookread) {
				System.out.println(b.toString());
				
			}
		}catch(Exception e) {
			  if(transaction!=null) {
				  transaction.rollback();
			  }else {
				  e.printStackTrace();
			  }
		  }
		
			
			return bookread;
		
	}
	
	
	//update data on the basis of book_id
	@SuppressWarnings("deprecation")
	@Override
	public void update(Book book) {
		String updateQuery = "update Book set book_name=:book_name,book_cost=:book_cost where book_id=:book_id";
		
		Transaction transaction =null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			@SuppressWarnings("unused")
			Query query = session.createQuery(updateQuery);
			query.setParameter("book_id",book.getBook_id());
			query.setParameter("book_name",book.getBook_name());
			query.setParameter("book_cost",book.getBook_cost());
			
			int result = query.executeUpdate();
		
			System.out.println("Rows affected: " +result);
			
			
			transaction.commit();
			
		}catch(Exception e) {
			
				e.printStackTrace();
			
		}
		
	}
	

	

	//delete data on the basis of book_id
	@SuppressWarnings("deprecation")
	@Override
	public void delete(long book_id) {
		
		Book book = null;
		Transaction transaction =null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			book = session.get(Book.class, book_id);
			session.delete(book);
			transaction.commit();
			
		}catch(Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}else {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public Book find(long book_id) {
		Transaction transaction =null;
		Book bookfind = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			//get a Book object
			transaction = session.beginTransaction();
			String sqlFind = " FROM Book WHERE book_id= :book_id";
			Query queryFind = session.createQuery(sqlFind);
			queryFind.setParameter("book_id", book_id);
			List results = queryFind.getResultList();
			if(results!=null && !results.isEmpty()) {
				bookfind = (Book) results.get(0);
			}
			transaction.commit();
			
		}catch(Exception e) {
			if(transaction!=null) {
				transaction.rollback();
			}else {
				e.printStackTrace();
			}
		}
		return bookfind;
		
	}




	

}
