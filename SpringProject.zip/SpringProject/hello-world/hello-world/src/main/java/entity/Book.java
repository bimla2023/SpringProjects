package entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="book")
public class Book {

@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="book_id")
 private long book_id;

@Column(name="book_name")
 private String book_name;

@Column(name="book_cost")
 private long book_cost;
 
//emptity constructor
public Book() {
	
}
 public Book(Book book) {
	
	}
 
 public Book(String book_name, long book_cost) {
		
	
		this.book_name = book_name;
		this.book_cost = book_cost;
	}
 
public Book(long book_id, String book_name, long book_cost) {
	
	this.book_id = book_id;
	this.book_name = book_name;
	this.book_cost = book_cost;
}

public long getBook_id() {
	return book_id;
}
public void setBook_id(long book_id) {
	this.book_id = book_id;
}
public String getBook_name() {
	return book_name;
}
public void setBook_name(String book_name) {
	this.book_name = book_name;
}
public long getBook_cost() {
	return book_cost;
}
public void setBook_cost(long book_cost) {
	this.book_cost = book_cost;
}


@Override
public String toString() {
	return "Book [book_id=" + book_id + ", book_name=" + book_name + ", book_cost=" + book_cost + "]";
}
 

}
