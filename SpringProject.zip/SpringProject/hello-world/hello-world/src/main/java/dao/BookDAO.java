package dao;

import java.util.List;

import org.hibernate.Session;

import entity.Book;

public interface BookDAO {
	
	
	public void create(String book_name,long book_cost);
	public Book find(long book_id);
	public void update(Book book);
	public void delete(long book_id);
	public List<Book> read();
	

}
