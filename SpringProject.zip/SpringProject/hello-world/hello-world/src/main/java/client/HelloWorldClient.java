package client;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.BookDAO;
import daoIMPL.BookDAOImpl;
import util.HibernateUtil;
import entity.Book;
import entity.Message;


public class HelloWorldClient {
	
	
	public static void main(String[] args) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.getTransaction();
		
		int choice;
		long book_id;
		String book_name;
		long book_cost;
		
				
        		do {
        			System.out.println("Displaying all the menu:");
        			System.out.println("1. CREATE BOOK");
        			System.out.println("2. READ BOOK");
        			System.out.println("3. UPDATE BOOK");
        			System.out.println("4. DELETE BOOK");
        			System.out.println("5. FIND BOOK");
        			System.out.println("6. EXIT");
        			System.out.println("Please enter your choice: ");
        			Scanner sc = new Scanner(System.in);
        			choice = sc.nextInt();
        			
        			
        			switch (choice) {
        			  case 1:
        				  
        				  System.out.println("Insert the Book Name");
        				  book_name = sc.next();
        				  System.out.println("Insert the Book Cost");
        				  book_cost = sc.nextInt();
        				  BookDAOImpl bookDao= new BookDAOImpl();
        				  bookDao.create(book_name, book_cost);
        				  
        					
        					
        				  break;
        			  case 2:
        				   BookDAOImpl bookDao1= new BookDAOImpl();
        				   bookDao1.read();
        				  
        				  break;
        				  
        			  case 3:
        				  Book book =new Book();
        				  BookDAOImpl bookDaoupdate= new BookDAOImpl();
        				  System.out.println("Insert the Book Id You want to Update Record");
        				  book_id = sc.nextLong();
        				  book.setBook_id(book_id);
        				  System.out.println("Insert the Book Name of the Book: ");
        				  book_name = sc.next();
        				  book.setBook_name(book_name);
        				  System.out.println("Insert the Book cost: ");
        				  book_cost = sc.nextLong();
        				  book.setBook_cost(book_cost);
        				
        				  bookDaoupdate.update(book);
        				  System.out.println("==updated succesfully==");
        				 
        				  
        				  break;
        			  case 4:
        				  System.out.println("Insert the Book Id You want to Delete Record");
        				  book_id = sc.nextLong();
        				  
        				  BookDAOImpl bookDeletee= new BookDAOImpl();
        				  bookDeletee.delete(book_id);
        				  System.out.println("==Book deleted successfully==");
        				  
        				  break;
        			
        			  case 5:
        				  Book bookfind =new Book();
        				  BookDAOImpl bookFindDAOimpl= new BookDAOImpl();
        				  System.out.println("Insert the Book Id You want to read");
        				  book_id = sc.nextLong();
        				  bookfind.setBook_id(book_id);
        				  bookfind = bookFindDAOimpl.find(book_id);
        				  System.out.println("Book Name: "+bookfind.getBook_name());
        				  break;
        			  case 6:
        				  System.out.println("==Thanks for saving the data==");
        				  System.exit(choice);
        			   
        			}


        			
        		}while(choice!=6) ;
        	
        		
        		
        		//Get method
        	/*	try {
        			transaction.begin();
        			//Object message
        			Message message1 = session.get(Message.class, 1L);
        			System.out.println(message1);
        			
        			Message message2 = session.get(Message.class, 3L);
        			System.out.println(message2);
        			
        		}catch(Exception e) {
        			if(transaction!=null) {
        				transaction.rollback();
        				e.printStackTrace();
        			}
        		}finally {
        			session.close();
        		}
			*/
        		
        		//delete
        		
        		
        		
				//to Insert
				/*session.beginTransaction();
      			Message message1 = new Message( "New message annotation" );
        
        		session.persist(message1); 
        
        		session.getTransaction().commit();
        		session.close();*/
				
			
				
	
	}
}

