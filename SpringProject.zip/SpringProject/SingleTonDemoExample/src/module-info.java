/**
 * 
 */
/**
 * 
 */
module SingleTonDemoExample {
}