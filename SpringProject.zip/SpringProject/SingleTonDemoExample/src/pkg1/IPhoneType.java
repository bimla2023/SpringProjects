package pkg1;

public enum IPhoneType {
	ELEVEN,
	TWELEVE

}
