package pkg1;

public class SingletonDesignPattern {

	public static void main(String[] args) {
		
		//call all the getInstance method

	}
}
	// first way of creating a singleton
	class Singlton1 {
		//static member
		private static final Singlton1 INSTANCE = new Singlton1();
		//private constructor
		private Singlton1() {
			
		}
		 
		public static Singlton1 getInnstance() {
			return INSTANCE;
		}
	}
	
	//second way

	class Singlton2 {
		private static Singlton2 Instance;
		
		static {
			
			Instance = new Singlton2();
	}
		public static Singlton2 getInnstance() {
			return Instance;
		}
		
	}
	
	//3rd way
	
	class Singlton3 {
		private Singlton3() {
			
		}
		private static Singlton3 singletonInstance;
		public static Singlton3 getsingletonInstance() {
			if(singletonInstance==null) {
				singletonInstance = new Singlton3();
			}
			return singletonInstance;
		}
		
	}
		

