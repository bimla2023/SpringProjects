package pkg1;

public class FactoryDesignPatternDemo {

	public static void main(String[] args) {
		System.out.println(IPhoneFactory.getIPhone(IPhoneType.ELEVEN));
		System.out.println(IPhoneFactory.getIPhone(IPhoneType.TWELEVE));
	
		

	}

}

interface IPhone{ 
	
	public String getRam();
	public String getMemory();
	public String getScreenSize();
}


class IPhone11 implements IPhone{
	
	private String ram;
	private String memory;
	private String screensize;
	

	
	public IPhone11(String ram, String memory, String screensize) {
		super();
		this.ram = ram;
		this.memory = memory;
		this.screensize = screensize;
	}

	@Override
	public String getRam() {
	
		return ram;
	}
	
	public String setRam() {
		
		return this.ram = ram;
	}

	@Override
	public String getMemory() {
		// TODO Auto-generated method stub
		return memory;
	}

	public String setMemory() {
		// TODO Auto-generated method stub
		return this.memory = memory;
	}
	@Override
	public String getScreenSize() {
		// TODO Auto-generated method stub
		return screensize;
	}
	public String setScreenSize() {
		// TODO Auto-generated method stub
		return screensize= screensize;
	}
	@Override
	public String toString() {
		return "IPhone12 [ram=" + ram + ", memory=" + memory + ", screensize=" + screensize + "]";
	}
	
}



class IPhone12 implements IPhone{
	
	private String ram;
	private String memory;
	private String screensize;
	
	public IPhone12(String ram, String memory, String screensize) {
		super();
		this.ram = ram;
		this.memory = memory;
		this.screensize = screensize;
	}


	@Override
	public String getRam() {
	
		return ram;
	}
	
	public String setRam() {
		
		return this.ram = ram;
	}

	@Override
	public String getMemory() {
		// TODO Auto-generated method stub
		return memory;
	}

	public String setMemory() {
		// TODO Auto-generated method stub
		return this.memory = memory;
	}
	@Override
	public String getScreenSize() {
		// TODO Auto-generated method stub
		return screensize;
	}
	public String setScreenSize() {
		// TODO Auto-generated method stub
		return screensize= screensize;
	}


	@Override
	public String toString() {
		return "IPhone12 [ram=" + ram + ", memory=" + memory + ", screensize=" + screensize + "]";
	}
	
	
	
	
}

class IPhoneFactory{
	
	public static IPhone getIPhone(IPhoneType iphoneType) {
		
		
		if(iphoneType.equals((iphoneType.ELEVEN))) {
			return new IPhone11("4GB","243GB","4.4");
			
		}else if(iphoneType.equals((iphoneType.TWELEVE))) {
			return new IPhone12("8GB","500GB","6.4");
		}
		
		else {
			return null;
		}
		
		
	}
	
}

