package pkg1;

public class BuilderDesignPatternDemo {

	public static void main(String[] args) {
		Car car = new Car.CarBuilder("Tyer", "Digital", "Power", "cco","aa",true,true).setAc(true).setSpeaker("Boat speakers").build();
		System.out.println(car);
		

	}
}
class Car {
	private String tyre;
	private String steering;
	private String engine;
	private String seats;
	
	
	
	//Optional attributes
	
	private String speakers;
	private boolean hasAC;
	private boolean hasSeatCover;
	


	//constructor
	public Car(CarBuilder carbuilder) {
		
		this.tyre = tyre;
		this.steering = steering;
		this.engine = engine;
		this.seats = seats;
		this.speakers = speakers;
		this.hasAC = hasAC;
		this.hasSeatCover = hasSeatCover;
	}
	
	public static class CarBuilder{
		
		private String tyre;
		private String steering;
		private String engine;
		private String seats;
		//optional 
		
		private String speakers;
		private boolean hasAC;
		private boolean hasSeatCover;
		public CarBuilder(String tyre, String steering, String engine, String seats, String speakers,boolean hasAC,boolean hasSeatCover) {
			super();
			this.tyre = tyre;
			this.steering = steering;
			this.engine = engine;
			this.seats = seats;
			this.speakers = speakers;
			this.hasAC = hasAC;
			this.hasSeatCover = hasSeatCover;
			
			
		}
		public CarBuilder setAc(boolean b) {
			// TODO Auto-generated method stub
			return this;
		}
		public CarBuilder setSpeaker(String speakers) {
			this.speakers = speakers;
			return this;
		}
		public CarBuilder setHasAc(boolean hasAC) {
			this.speakers = speakers;
			return this;
		}
		public CarBuilder setseatCover(boolean hasseatCover) {
			this.speakers = speakers;
			return this;
		}
		public Car build() {
			return new Car(this);
			
		}
		public String getTyre() {
			return tyre;
		}
		public void setTyre(String tyre) {
			this.tyre = tyre;
		}
		public String getSteering() {
			return steering;
		}
		public void setSteering(String steering) {
			this.steering = steering;
		}
		public String getEngine() {
			return engine;
		}
		public void setEngine(String engine) {
			this.engine = engine;
		}
		public String getSeats() {
			return seats;
		}
		public void setSeats(String seats) {
			this.seats = seats;
		}
		public String getSpeakers() {
			return speakers;
		}
		public void setSpeakers(String speakers) {
			this.speakers = speakers;
		}
		public boolean isHasAC() {
			return hasAC;
		}
		public void setHasAC(boolean hasAC) {
			this.hasAC = hasAC;
		}
		public boolean isHasSeatCover() {
			return hasSeatCover;
		}
		public void setHasSeatCover(boolean hasSeatCover) {
			this.hasSeatCover = hasSeatCover;
		}
	
		
		
		
		
	}
	
	@Override
	public String toString() {
		return "CarBuilder [tyre=" + tyre + ", steering=" + steering + ", engine=" + engine + ", seats=" + seats
				+ ", speakers=" + speakers + ", hasAC=" + hasAC + ", hasSeatCover=" + hasSeatCover + "]";
	}
	
	
	
}


