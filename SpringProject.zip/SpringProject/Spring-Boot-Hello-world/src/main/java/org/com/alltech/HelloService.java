package org.com.alltech;

import org.springframework.stereotype.Component;

@Component
public class HelloService {
	public String sayHello() {
		return "Welcome Spring Boot , How are you";
	}

}
