package org.com.alltech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringBootHelloWorldApplication {

	public static void main(String[] args) {
	
		ApplicationContext ctx =   SpringApplication.run(SpringBootHelloWorldApplication.class, args);
		HelloService hello = ctx.getBean(HelloService.class);
		String message = hello.sayHello();
		System.out.println(message);
		
		//for beans displaying
		/*ConfigurableApplicationContext ctx1 =   SpringApplication.run(SpringBootHelloWorldApplication.class, args);
		for(String str: ctx1.getBeanDefinitionNames()) {
			System.out.println(str);
		}*/
	}

}
