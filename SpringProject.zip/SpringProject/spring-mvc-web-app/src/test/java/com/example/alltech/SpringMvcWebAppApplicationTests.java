package com.example.alltech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
