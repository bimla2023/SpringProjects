package org.com.gl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorlWebMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloWorlWebMvcApplication.class, args);
	}

}
